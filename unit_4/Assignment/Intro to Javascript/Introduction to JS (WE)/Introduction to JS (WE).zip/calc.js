let v1 = 6;
let v2 = 3;

let addition = v1 + v2 ;
let subtraction = v1 - v2 ;
let multiplication = v1 * v2 ;
let division = v1 / v2 ;
let remainder = v1 % v2 ;
let increment = ++v1;
let decrement = --v2;
let diff = Math.pow(v1,v2) - Math.pow(v2,v1) ;

console.log("addition", addition);
console.log("subtraction", subtraction)
console.log("multiplication", multiplication)
console.log("division", division)
console.log("remainder", remainder)
console.log("increment", increment)
console.log("decrement", decrement)
console.log("diff", diff)