let dob = 2002;
let currYear = 2022;

let age = currYear - dob ;
console.log("age", age)
