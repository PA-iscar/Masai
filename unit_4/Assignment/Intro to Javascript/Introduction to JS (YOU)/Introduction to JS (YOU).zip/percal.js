let m1 = 73, m2 = 85, m3 = 62;
let perc = (m1+m2+m3)/3;
console.log(`${perc.toFixed(2)}%`)