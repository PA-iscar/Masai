let len = 17, bre = 10;

let peri = 2*(len+bre);
let area = len*bre;

console.log(peri)
console.log(area)